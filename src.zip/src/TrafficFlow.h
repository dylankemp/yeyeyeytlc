/*
 * TrafficFlow.h
 *
 *  Created on: Feb 25, 2019
 */

#ifndef TRAFFICFLOW_H_
#define TRAFFICFLOW_H_

#include "STMRTOSconfig.h"

void TrafficFlowAdjustmentTask( void *pvParameters );

#endif /* TRAFFICFLOW_H_ */

