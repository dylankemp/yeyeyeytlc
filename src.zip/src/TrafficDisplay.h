/*
 * TrafficDisplay.h
 *
 *  Created on: Feb 25, 2019
 *      Author: brendanb
 */

#ifndef TRAFFICDISPLAY_H_
#define TRAFFICDISPLAY_H_

#include "ShiftRegister.h"
#include "STMRTOSconfig.h"

void TrafficDisplayTask( void *pvParameters );


#endif /* TRAFFICDISPLAY_H_ */


